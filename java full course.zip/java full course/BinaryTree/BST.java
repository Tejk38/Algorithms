//package BinaryTree;
//
//public class BST {
//
//    private class Node {
//        int value;
//        Node left;
//        Node right;
//
//        public sNode(int value) {
//            this.value = value;
//
//        }
//
//    }
//    public Node root;
//    public void BST(){
//        root = null;
//    }
//
//    public void insert(Node node, int value){
//        if(value<node.value){
//            if(node.left!=null){
//                insert(node.left,value);
//
//            }
//            else {
//                node.left = new Node(value);
//            }
//        }
//
//    }
//
//}
