package methodsAndFunctions;

public class PassingExample {
    public static void main(String[] args) {
        String name = "tej";
        greet(name);
    }

   static void greet(String name) {
       System.out.println(name);
    }
}
