package Revision.searching;

public class ArrangeCoins {
    static int arrangecoins(int num){
        int l = (num+1)/2;
        int[][] ar = new int[l][];
        for (int i = 0; i < l; i++) {
            for (int j = 0; j < ar[i].length; j++) {

                

            }

        }
        return 0;
    }
}
