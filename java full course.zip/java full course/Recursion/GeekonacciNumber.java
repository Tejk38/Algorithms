package Recursion;

public class GeekonacciNumber {
}
