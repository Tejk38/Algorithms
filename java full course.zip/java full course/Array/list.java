package Array;

public class list<T> {
}
