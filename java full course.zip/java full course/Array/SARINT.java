package Array;

import java.util.ArrayList;

public class SARINT {
    static int addToArrayForm(int[] ar, int k){
        int len = ar.length;
        list<Integer> lt = new list<Integer>();
        int[] a = new int[ar.length];
        int num = 0;
        for (int i = 0; i < ar.length ; i++) {

            for (int t:ar){




            }




        }
        return -1;
    }
}
