package Array;
import java.util.ArrayList;
public class MultiArraylist {
}
