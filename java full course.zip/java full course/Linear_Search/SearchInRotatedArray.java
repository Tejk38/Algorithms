//package Linear_Search;
//
//public class SearchInRotatedArray {
//    static int search(int[] ar, int target){
//        int s = 0;
//        int e = ar.length-1;
//        int max = 0;
//        while(e>s){
//            int mid = s + (e-s)/2;
//            if(ar[mid] == target){
//                return mid;
//            }
//
//        }
//    }
//    private int peak(int[] ar){
//        int s = 0;
//        int e = ar.length-1;
//        while(e>s){
//            int mid = s+(e-s)/2;
////            if()
//        }
////    }
////}
