package LinkedList;


public class Double_LL {
    Node head;
    public Double_LL() {
        head = null;
    }
    public static void inset_one(int val){
        Node newNode = new Node(val);
        

    }
}

class Node{
    Node next;
    int data;

    Node(int val){
        data = val;
        next = null;
    }
}

